<?php
/**
 * Frontend Script Injection Handler
 *
 * @package OverSeek
 * @since   1.0.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class OverSeek_Frontend
 *
 * Handles frontend script injection based on settings.
 * Analytics tracking is 100% server-side via class-overseek-server-tracking.php.
 * This class handles the optional Live Chat widget only.
 *
 * @since 1.0.0
 */
class OverSeek_Frontend
{
	private const CHAT_CONFIG_TTL = 1800;
	private const CHAT_CONFIG_STALE_TTL = DAY_IN_SECONDS;
	private const CHAT_CONFIG_REFRESH_HOOK = 'overseek_refresh_chat_config';

	public function __construct()
	{
		add_action(self::CHAT_CONFIG_REFRESH_HOOK, array($this, 'handle_background_refresh'));
	}

	/**
	 * Print scripts to the footer if chat is enabled and within business hours.
	 * Analytics is handled server-side - no JavaScript needed.
	 *
	 * @return void
	 */
	public function print_scripts(): void
	{
		$chat_enabled = get_option('overseek_enable_chat');
		$api_url = get_option('overseek_api_url', '');
		$account_id = get_option('overseek_account_id');

		// Early exit if chat not configured.
		if (!$chat_enabled || empty($account_id)) {
			return;
		}

		// Server-side business hours check - don't load widget outside hours.
		if (!$this->is_within_business_hours($api_url, $account_id)) {
			return;
		}

		$api_url = untrailingslashit($api_url);

		// Output after the body exists because the widget appends itself to document.body.
		echo "<!-- OverSeek Live Chat Widget v" . esc_html(OVERSEEK_WC_VERSION) . " -->\n";
		printf(
			'<script src="%s/api/chat/widget.js?id=%s&v=%s" defer crossorigin="anonymous"></script>%s',
			esc_url($api_url),
			esc_attr($account_id),
			esc_attr(OVERSEEK_WC_VERSION),
			PHP_EOL
		);
		echo "<!-- OverSeek Live Chat Widget End -->\n";
	}

	/**
	 * Check if current time is within configured business hours.
	 * Fetches config from OverSeek API and caches for 5 minutes.
	 *
	 * @param string $api_url    The OverSeek API URL.
	 * @param string $account_id The account identifier.
	 * @return bool True if within business hours or hours not configured.
	 */
	private function is_within_business_hours(string $api_url, string $account_id): bool
	{
		$config = $this->get_chat_config($api_url, $account_id);

		// If no business hours configured, always show chat.
		if (empty($config['businessHours']['enabled'])) {
			return true;
		}

		$business_hours = $config['businessHours'];
		$timezone = $config['businessTimezone'] ?? 'Australia/Sydney';

		try {
			$tz = new DateTimeZone($timezone);
			$now = new DateTime('now', $tz);

			$day_map = ['Sun' => 'sun', 'Mon' => 'mon', 'Tue' => 'tue', 'Wed' => 'wed', 'Thu' => 'thu', 'Fri' => 'fri', 'Sat' => 'sat'];
			$weekday = $day_map[$now->format('D')] ?? '';

			if (empty($business_hours['days'][$weekday])) {
				return false;
			}

			$schedule = $business_hours['days'][$weekday];

			if (empty($schedule['isOpen'])) {
				return false;
			}

			$current_minutes = (int) $now->format('H') * 60 + (int) $now->format('i');

			$open_parts  = explode(':', $schedule['open'] ?? '09:00');
			$close_parts = explode(':', $schedule['close'] ?? '17:00');

			if (count($open_parts) < 2 || count($close_parts) < 2) {
				return true; // Fail open on malformed time strings.
			}

			$open_h  = (int) $open_parts[0];
			$open_m  = (int) $open_parts[1];
			$close_h = (int) $close_parts[0];
			$close_m = (int) $close_parts[1];

			$open_minutes  = $open_h * 60 + $open_m;
			$close_minutes = $close_h * 60 + $close_m;

			if ($open_minutes < 0 || $close_minutes < 0 || $open_minutes > 1439 || $close_minutes > 1439) {
				return true; // Fail open on out-of-range time values.
			}

			return $current_minutes >= $open_minutes && $current_minutes <= $close_minutes;
		} catch (Exception $e) {
			// Fail open - show chat if timezone parsing fails.
			return true;
		}
	}

	/**
	 * Get chat configuration from OverSeek API with transient caching.
	 *
	 * @param string $api_url    The OverSeek API URL.
	 * @param string $account_id The account identifier.
	 * @return array<string, mixed> Chat configuration array.
	 */
	private function get_chat_config(string $api_url, string $account_id): array
	{
		$local = get_option('overseek_storefront_chat_config', false);
		if (is_array($local)) {
			return $local;
		}

		$fresh_key = 'overseek_chat_config_' . md5($account_id);
		$stale_key = 'overseek_chat_config_stale_' . md5($account_id);

		$cached = get_transient($fresh_key);

		if ($cached !== false && is_array($cached)) {
			return $cached;
		}

		$stale = get_transient($stale_key);
		if ($stale !== false && is_array($stale)) {
			$this->schedule_background_refresh($account_id);
			return $stale;
		}

		$this->schedule_background_refresh($account_id);
		return [];
	}

	private function schedule_background_refresh(string $account_id): void
	{
		if ('' === $account_id) {
			return;
		}

		if (!wp_next_scheduled(self::CHAT_CONFIG_REFRESH_HOOK, array($account_id))) {
			wp_schedule_single_event(time(), self::CHAT_CONFIG_REFRESH_HOOK, array($account_id));
		}
	}

	public function handle_background_refresh(string $account_id): void
	{
		$api_url = (string) get_option('overseek_api_url', '');
		$this->refresh_chat_config($api_url, $account_id);
	}

	private function refresh_chat_config(string $api_url, string $account_id): array
	{
		if ('' === $api_url || '' === $account_id) {
			return array();
		}

		$api_url = untrailingslashit($api_url);
		$response = wp_remote_get(
			$api_url . '/api/chat/config/' . $account_id,
			[
				'timeout' => 2,
				'headers' => ['Accept' => 'application/json'],
			]
		);

		if (is_wp_error($response)) {
			// On error, return empty config (fail open).
			return [];
		}

		$data = OverSeek_HTTP_Utils::decode_json_response($response);

		if (!is_array($data)) {
			return [];
		}

		$fresh_key = 'overseek_chat_config_' . md5($account_id);
		$stale_key = 'overseek_chat_config_stale_' . md5($account_id);

		set_transient($fresh_key, $data, self::CHAT_CONFIG_TTL);
		set_transient($stale_key, $data, self::CHAT_CONFIG_STALE_TTL);
		update_option('overseek_storefront_chat_config', $data, false);

		return $data;
	}

}
