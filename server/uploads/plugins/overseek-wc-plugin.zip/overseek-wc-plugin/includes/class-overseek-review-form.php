<?php
/**
 * Custom native WooCommerce review form.
 *
 * @package OverSeek
 * @since   2.17.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles review form rendering, submission, and optional product tab replacement.
 */
class OverSeek_Review_Form {
	private const NONCE_ACTION = 'overseek_submit_review';
	private const NONCE_NAME   = 'overseek_review_nonce';
	private const MAX_FILES    = 6;
	private const MAX_BYTES    = 10485760;
	private const RATE_LIMIT_MAX = 5;
	private const RATE_LIMIT_WINDOW = HOUR_IN_SECONDS;
	private const DUPLICATE_SUBMISSION_COOLDOWN = 2 * MINUTE_IN_SECONDS;
	private const DUPLICATE_LOCK_CLEANUP_KEY = 'os_review_dup_cleanup';

	/**
	 * Track forms already rendered during the request to avoid duplicate fallbacks.
	 *
	 * @var array<string, bool>
	 */
	private array $rendered_forms = [];

	/**
	 * Form instance counter used to keep field IDs unique.
	 *
	 * @var int
	 */
	private int $form_counter = 0;

	/**
	 * Initialize hooks.
	 */
	public function __construct() {
		add_filter( 'pre_comment_approved', [ 'OverSeek_Review_Moderation', 'filter_approval' ], 20, 2 );
		add_shortcode( 'overseek_review_form', [ $this, 'render_shortcode' ] );
		add_action( 'admin_post_overseek_submit_review', [ $this, 'handle_submission' ] );
		add_action( 'admin_post_nopriv_overseek_submit_review', [ $this, 'handle_submission' ] );
		add_action( 'wp_ajax_overseek_review_nonce', [ $this, 'send_fresh_nonce' ] );
		add_action( 'wp_ajax_nopriv_overseek_review_nonce', [ $this, 'send_fresh_nonce' ] );
		add_action( 'template_redirect', [ $this, 'disable_cache_for_review_requests' ], 0 );
		add_action( 'woocommerce_after_single_product_summary', [ $this, 'render_review_request_fallback' ], 11 );
		add_filter( 'woocommerce_product_tabs', [ $this, 'maybe_replace_reviews_tab' ], 999 );
	}

	/**
	 * Review-request URLs must render a fresh page so the direct form is available.
	 *
	 * @return void
	 */
	public function disable_cache_for_review_requests(): void {
		if ( ! $this->is_review_request() ) {
			return;
		}

		$this->mark_page_uncacheable();
	}

	/**
	 * Mark a page containing a customer-specific nonce as uncacheable.
	 *
	 * @return void
	 */
	private function mark_page_uncacheable(): void {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		if ( function_exists( 'do_action' ) ) {
			do_action( 'litespeed_control_set_nocache', 'OverSeek review request' );
		}

		if ( ! headers_sent() ) {
			nocache_headers();
		}
	}

	/**
	 * Check whether this page was opened from a review request.
	 *
	 * @return bool
	 */
	private function is_review_request(): bool {
		return ! empty( $_GET['overseek_review_request'] ) || ! empty( $_GET['overseek_review_rating'] );
	}

	/**
	 * Return an uncached nonce for forms served from full-page caches.
	 *
	 * @return void
	 */
	public function send_fresh_nonce(): void {
		nocache_headers();
		wp_send_json_success( [ 'nonce' => wp_create_nonce( self::NONCE_ACTION ) ] );
	}

	/**
	 * Render the review form shortcode.
	 *
	 * @param array<string, mixed> $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts = [] ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$attributes = shortcode_atts(
			[
				'product_id' => 0,
				'shop_review' => 'false',
				'title'      => __( 'Write a review', 'overseek-wc' ),
			],
			$atts,
			'overseek_review_form'
		);

		$shop_review = $this->truthy( $attributes['shop_review'] ?? false );
		$product_id  = $shop_review ? $this->get_shop_review_post_id() : absint( $attributes['product_id'] );
		if ( ! $product_id ) {
			$product_id = $this->get_current_product_id();
		}

		return $this->render_form( $product_id, (string) $attributes['title'], $shop_review );
	}

	/**
	 * Replace WooCommerce's reviews tab content when enabled.
	 *
	 * @param array<string, mixed> $tabs Product tabs.
	 * @return array<string, mixed>
	 */
	public function maybe_replace_reviews_tab( array $tabs ): array {
		if ( ! $this->should_replace_product_reviews() ) {
			return $tabs;
		}

		if ( isset( $tabs['reviews'] ) ) {
			$tabs['reviews']['callback'] = [ $this, 'render_product_reviews_tab' ];
		}

		return $tabs;
	}

	/**
	 * Render replacement product reviews tab.
	 *
	 * @param string $key Tab key.
	 * @param array<string, mixed> $tab Tab config.
	 * @return void
	 */
	public function render_product_reviews_tab( string $key = '', array $tab = [] ): void {
		$product_id = $this->get_current_product_id();
		if ( ! $product_id ) {
			return;
		}

		echo '<section id="reviews" class="woocommerce-Reviews os-product-reviews" data-os-product-reviews>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo do_shortcode( '[overseek_product_reviews product_id="' . absint( $product_id ) . '" limit="12" pagination="load_more" show_media="1" add_review="1"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Render a direct form when the theme does not expose one.
	 *
	 * @return void
	 */
	public function render_review_request_fallback(): void {
		if ( ! ( function_exists( 'is_product' ) && is_product() ) ) {
			return;
		}
		if ( ! $this->should_replace_product_reviews() && ! $this->is_review_request() ) {
			return;
		}

		$product_id = $this->get_current_product_id();
		$key        = $this->get_rendered_form_key( $product_id, false );
		if ( ! $product_id || ! empty( $this->rendered_forms[ $key ] ) ) {
			return;
		}

		$form = $this->render_form( $product_id, __( 'Write a review', 'overseek-wc' ), false );
		if ( '' === $form ) {
			return;
		}

		echo '<section class="os-review-request-fallback">' . $form . '</section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Check if product review replacement is enabled.
	 *
	 * @return bool
	 */
	private function should_replace_product_reviews(): bool {
		return '1' === (string) get_option( 'overseek_reviews_replace_form', '' );
	}

	/**
	 * Handle frontend review submissions.
	 *
	 * @return void
	 */
	public function handle_submission(): void {
		$product_id  = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$shop_review = ! empty( $_POST['shop_review'] );
		$redirect    = $this->get_submitted_redirect_url( $shop_review ? home_url( '/' ) : $this->get_review_redirect_url( $product_id ) );

		$nonce = isset( $_POST[ self::NONCE_NAME ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) ) : '';
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			$this->redirect_with_status( $redirect, 'invalid-nonce' );
		}

		if ( ! $this->passes_spam_checks() ) {
			$this->redirect_with_status( $redirect, 'spam-check' );
		}

		if ( ! $shop_review ) {
			$product_id = $this->resolve_product_id( $product_id, $redirect );
		}

		if ( ! $shop_review ) {
			$product_id = $this->normalize_product_review_id( $product_id );
		}

		$product      = ! $shop_review && $product_id ? wc_get_product( $product_id ) : null;
		$product_type = $product_id ? get_post_type( $product_id ) : '';
		if ( $shop_review ) {
			$product_id = $this->get_shop_review_post_id();
		} elseif ( ! $product || 'product' !== $product_type ) {
			$this->redirect_with_status( $redirect, 'invalid-product' );
		}

		$rating  = isset( $_POST['rating'] ) ? absint( $_POST['rating'] ) : 0;
		$content = isset( $_POST['review'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['review'] ) ) ) : '';
		$name    = isset( $_POST['author'] ) ? sanitize_text_field( wp_unslash( $_POST['author'] ) ) : '';
		$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$name         = (string) $current_user->display_name;
			$email        = (string) $current_user->user_email;
		}

		if ( $rating < 1 || $rating > 5 || '' === $content || '' === $name || ! is_email( $email ) ) {
			$this->redirect_with_status( $redirect, 'missing' );
		}

		if ( ! $shop_review && ! $this->product_review_submission_allowed( $product_id, $email ) ) {
			$this->redirect_with_status( $redirect, 'not-allowed' );
		}

		if ( ! $this->passes_rate_limit( $email ) ) {
			$this->redirect_with_status( $redirect, 'rate-limited' );
		}

		$duplicate_lock_key = $this->get_duplicate_submission_lock_key( $product_id, $shop_review, $email, $rating, $content );
		if ( ! $this->acquire_duplicate_submission_lock( $duplicate_lock_key ) ) {
			$this->redirect_with_status( $redirect, 'duplicate' );
		}

		$is_verified = ! $shop_review && $this->is_verified_customer( $product_id, $email );
		$country    = $this->get_customer_country();
		$comment_meta = [
			'rating'               => $rating,
			'overseek_shop_review' => $shop_review ? '1' : '0',
			'overseek_country'     => $country,
		];
		if ( $is_verified ) {
			$comment_meta['overseek_verified_owner'] = '1';
		}
		$comment_id = wp_new_comment(
			[
				'comment_post_ID'      => $product_id,
				'comment_author'       => $name,
				'comment_author_email' => $email,
				'comment_content'      => $content,
				'comment_type'         => 'review',
				'comment_author_IP'    => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
				'comment_agent'        => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 254 ) : '',
				'user_id'              => get_current_user_id(),
				'comment_meta'         => $comment_meta,
			],
			true
		);

		if ( ! $comment_id || is_wp_error( $comment_id ) ) {
			$this->release_duplicate_submission_lock( $duplicate_lock_key );
			if ( is_wp_error( $comment_id ) && 'comment_duplicate' === $comment_id->get_error_code() ) {
				$this->redirect_with_status( $redirect, 'duplicate' );
			}
			$this->redirect_with_status( $redirect, 'failed' );
		}

		update_comment_meta( (int) $comment_id, 'rating', $rating );
		update_comment_meta( (int) $comment_id, 'overseek_shop_review', $shop_review ? '1' : '0' );
		if ( $is_verified ) {
			update_comment_meta( (int) $comment_id, 'verified', 1 );
		}
		if ( '' !== $country ) {
			update_comment_meta( (int) $comment_id, 'overseek_country', $country );
		}

		$media_ids = $this->handle_media_uploads( $product_id );
		if ( ! empty( $media_ids ) ) {
			update_comment_meta( (int) $comment_id, 'overseek_media_ids', $media_ids );
		}

		$status = wp_get_comment_status( (int) $comment_id );
		$this->redirect_with_status( $redirect, 'approved' === $status ? 'published' : 'submitted' );
	}

	/**
	 * Render review form markup.
	 *
	 * @param int    $product_id Product ID.
	 * @param string $title Form title.
	 * @return string
	 */
	private function render_form( int $product_id, string $title, bool $shop_review = false ): string {
		if ( ! $product_id ) {
			return '';
		}

		if ( ! $shop_review ) {
			$product_id = $this->normalize_product_review_id( $product_id );
			if ( ! $product_id || ! $this->product_review_form_allowed( $product_id ) ) {
				return '';
			}
		}

		$this->rendered_forms[ $this->get_rendered_form_key( $product_id, $shop_review ) ] = true;
		$form_number = ++$this->form_counter;
		$form_id     = 1 === $form_number ? 'review_form' : 'overseek-review-form-' . $form_number;
		$field_id    = 'os-review-' . $form_number;

		$prefilled_rating = isset( $_GET['overseek_review_rating'] ) ? absint( wp_unslash( $_GET['overseek_review_rating'] ) ) : 0;
		if ( $prefilled_rating < 1 || $prefilled_rating > 5 ) {
			$prefilled_rating = 0;
		}
		$prefilled_name  = isset( $_GET['overseek_review_name'] ) ? sanitize_text_field( wp_unslash( $_GET['overseek_review_name'] ) ) : '';
		$prefilled_email = isset( $_GET['overseek_review_email'] ) ? sanitize_email( wp_unslash( $_GET['overseek_review_email'] ) ) : '';
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$prefilled_name = '' !== $prefilled_name ? $prefilled_name : (string) $current_user->display_name;
			$prefilled_email = '' !== $prefilled_email ? $prefilled_email : (string) $current_user->user_email;
		}

		ob_start();
		?>
		<?php echo $this->render_submission_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<form id="<?php echo esc_attr( $form_id ); ?>" class="os-review-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" data-os-review-nonce-url="<?php echo esc_url( admin_url( 'admin-ajax.php?action=overseek_review_nonce' ) ); ?>">
			<header class="os-review-form__header">
				<h3><?php echo esc_html( $title ); ?></h3>
				<p><?php esc_html_e( 'Share your experience to help other customers.', 'overseek-wc' ); ?></p>
			</header>
			<input type="hidden" name="action" value="overseek_submit_review">
			<input type="hidden" name="product_id" value="<?php echo esc_attr( (string) $product_id ); ?>">
			<input type="hidden" name="redirect_to" value="<?php echo esc_url( $this->get_current_request_url() ); ?>">
			<input type="hidden" name="rendered_at" value="<?php echo esc_attr( (string) time() ); ?>">
			<input type="text" name="overseek_review_contact_url" value="" tabindex="-1" autocomplete="off" class="os-review-form__website" aria-hidden="true" readonly>
			<?php if ( $shop_review ) : ?>
				<input type="hidden" name="shop_review" value="1">
			<?php endif; ?>
			<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

			<fieldset class="os-review-form__field os-review-form__rating">
				<legend><?php esc_html_e( 'Rating', 'overseek-wc' ); ?></legend>
				<div class="os-review-form__stars" aria-label="<?php esc_attr_e( 'Choose a rating', 'overseek-wc' ); ?>">
					<?php for ( $star = 5; $star >= 1; $star-- ) : ?>
						<input id="<?php echo esc_attr( $field_id . '-rating-' . $star ); ?>" type="radio" name="rating" value="<?php echo esc_attr( (string) $star ); ?>" <?php checked( $prefilled_rating, $star ); ?> required>
						<label for="<?php echo esc_attr( $field_id . '-rating-' . $star ); ?>" aria-label="<?php echo esc_attr( sprintf( _n( '%d star', '%d stars', $star, 'overseek-wc' ), $star ) ); ?>">★</label>
					<?php endfor; ?>
				</div>
			</fieldset>

			<label class="os-review-form__field">
				<span><?php esc_html_e( 'Review', 'overseek-wc' ); ?></span>
				<textarea name="review" rows="4" placeholder="<?php esc_attr_e( 'What did you like? How was the quality and service?', 'overseek-wc' ); ?>" required></textarea>
			</label>

			<div class="os-review-form__grid">
				<label class="os-review-form__field">
					<span><?php esc_html_e( 'Name', 'overseek-wc' ); ?></span>
					<input type="text" name="author" value="<?php echo esc_attr( $prefilled_name ); ?>" autocomplete="name" <?php readonly( is_user_logged_in() ); ?> required>
				</label>

				<label class="os-review-form__field">
					<span><?php esc_html_e( 'Email', 'overseek-wc' ); ?></span>
					<input type="email" name="email" value="<?php echo esc_attr( $prefilled_email ); ?>" autocomplete="email" <?php readonly( is_user_logged_in() ); ?> required>
				</label>
			</div>

			<div class="os-review-form__actions">
				<label class="os-review-form__dropzone">
					<span class="os-review-form__upload-icon" aria-hidden="true">＋</span>
					<span><strong><?php esc_html_e( 'Add photos or video', 'overseek-wc' ); ?></strong><small data-os-review-file-label aria-live="polite"><?php echo esc_html( sprintf( __( 'Up to %1$d files, %2$s each', 'overseek-wc' ), self::MAX_FILES, size_format( $this->max_upload_bytes() ) ) ); ?></small></span>
					<input type="file" name="os_review_media[]" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/quicktime,video/webm" data-max-files="<?php echo esc_attr( (string) self::MAX_FILES ); ?>" data-max-bytes="<?php echo esc_attr( (string) $this->max_upload_bytes() ); ?>" multiple>
				</label>

				<button type="submit" class="os-review-form__submit" data-submitting-label="<?php esc_attr_e( 'Submitting...', 'overseek-wc' ); ?>"><?php esc_html_e( 'Submit review', 'overseek-wc' ); ?></button>
			</div>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Build a stable rendered-form key.
	 *
	 * @param int  $product_id  Product ID.
	 * @param bool $shop_review Whether this is a shop review form.
	 * @return string
	 */
	private function get_rendered_form_key( int $product_id, bool $shop_review ): string {
		return ( $shop_review ? 'shop' : 'product' ) . ':' . absint( $product_id );
	}

	/**
	 * Render submission feedback after redirects.
	 *
	 * @return string
	 */
	private function render_submission_notice(): string {
		if ( empty( $_GET['overseek_review_status'] ) ) {
			return '';
		}

		$status = sanitize_key( wp_unslash( $_GET['overseek_review_status'] ) );
		if ( 'submitted' === $status ) {
			return '<div class="os-review-form__notice os-review-form__notice--success">' . esc_html__( 'Thanks. Your review has been submitted and may be held briefly for moderation.', 'overseek-wc' ) . '</div>';
		}
		if ( 'published' === $status ) {
			return '<div class="os-review-form__notice os-review-form__notice--success">' . esc_html__( 'Thanks. Your review is now published.', 'overseek-wc' ) . '</div>';
		}

		if ( 'duplicate' === $status ) {
			return '<div class="os-review-form__notice os-review-form__notice--success">' . esc_html__( 'Thanks. We already received this review.', 'overseek-wc' ) . '</div>';
		}

		$messages = [
			'invalid-nonce'   => __( 'Your review form expired. Please refresh the page and try again.', 'overseek-wc' ),
			'invalid-product' => __( 'We could not match this review to the product. Please refresh the page and try again.', 'overseek-wc' ),
			'missing'         => __( 'Please complete the rating, review, name, and email fields.', 'overseek-wc' ),
			'not-allowed'     => __( 'Reviews are not available for this product right now.', 'overseek-wc' ),
			'rate-limited'    => __( 'Please wait before submitting another review.', 'overseek-wc' ),
			'spam-check'      => __( 'We could not submit your review. Please refresh the page and try again.', 'overseek-wc' ),
			'failed'          => __( 'WordPress could not save this review. Please try again.', 'overseek-wc' ),
		];

		return '<div class="os-review-form__notice os-review-form__notice--error">' . esc_html( $messages[ $status ] ?? __( 'We could not submit your review. Please check the form and try again.', 'overseek-wc' ) ) . '</div>';
	}

	/**
	 * Check whether submitted request contains media.
	 *
	 * @return bool
	 */
	private function has_uploaded_media(): bool {
		return isset( $_FILES['os_review_media']['name'] ) && is_array( $_FILES['os_review_media']['name'] ) && ! empty( array_filter( $_FILES['os_review_media']['name'] ) );
	}

	/**
	 * Apply lightweight bot checks before creating a review.
	 *
	 * @return bool
	 */
	private function passes_spam_checks(): bool {
		if ( ! empty( $_POST['overseek_review_contact_url'] ) ) {
			return false;
		}

		$rendered_at = isset( $_POST['rendered_at'] ) ? absint( $_POST['rendered_at'] ) : 0;
		return ! $rendered_at || $rendered_at <= time();
	}

	private function passes_rate_limit( string $email ): bool {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'os_review_rate_' . substr( hash( 'sha256', strtolower( $email ) . '|' . $ip ), 0, 20 );
		$count = (int) get_transient( $key );

		if ( $count >= self::RATE_LIMIT_MAX ) {
			return false;
		}

		set_transient( $key, $count + 1, self::RATE_LIMIT_WINDOW );
		return true;
	}

	private function get_duplicate_submission_lock_key( int $product_id, bool $shop_review, string $email, int $rating, string $content ): string {
		$ip          = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$fingerprint = implode(
			'|',
			[
				$shop_review ? 'shop' : 'product',
				(string) $product_id,
				strtolower( $email ),
				(string) $rating,
				trim( preg_replace( '/\s+/', ' ', $content ) ?? $content ),
				$ip,
			]
		);

		return 'os_review_dup_' . substr( hash( 'sha256', $fingerprint ), 0, 32 );
	}

	private function acquire_duplicate_submission_lock( string $key ): bool {
		$this->cleanup_expired_duplicate_submission_locks();

		$expires_at = time() + self::DUPLICATE_SUBMISSION_COOLDOWN;
		$existing   = get_option( $key, 0 );

		if ( $existing && (int) $existing > time() ) {
			return false;
		}

		if ( $existing ) {
			delete_option( $key );
		}

		return add_option( $key, (string) $expires_at, '', 'no' );
	}

	private function release_duplicate_submission_lock( string $key ): void {
		delete_option( $key );
	}

	private function cleanup_expired_duplicate_submission_locks(): void {
		if ( get_transient( self::DUPLICATE_LOCK_CLEANUP_KEY ) ) {
			return;
		}

		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) <= %d",
				$wpdb->esc_like( 'os_review_dup_' ) . '%',
				time()
			)
		);

		set_transient( self::DUPLICATE_LOCK_CLEANUP_KEY, '1', HOUR_IN_SECONDS );
	}

	private function product_review_form_allowed( int $product_id ): bool {
		if ( $product_id <= 0 || 'product' !== get_post_type( $product_id ) ) {
			return false;
		}

		return ! function_exists( 'wc_get_product' ) || false !== wc_get_product( $product_id );
	}

	private function product_review_submission_allowed( int $product_id, string $email ): bool {
		if ( ! $this->product_review_form_allowed( $product_id ) ) {
			return false;
		}

		if ( 'yes' !== (string) get_option( 'woocommerce_review_rating_verification_required', 'no' ) ) {
			return true;
		}

		return $this->is_verified_customer( $product_id, $email );
	}

	/**
	 * Verify ownership using WooCommerce's native customer/order lookup.
	 *
	 * @param int    $product_id Reviewed product ID.
	 * @param string $email      Canonical account email.
	 * @return bool
	 */
	private function is_verified_customer( int $product_id, string $email ): bool {
		if ( ! function_exists( 'wc_customer_bought_product' ) ) {
			return false;
		}

		$user_id = is_user_logged_in() ? get_current_user_id() : 0;
		return wc_customer_bought_product( $email, $user_id, $product_id );
	}

	/**
	 * Resolve a reviewer's country without adding another form field.
	 *
	 * @return string
	 */
	private function get_customer_country(): string {
		$config = get_option( 'overseek_storefront_review_config', [] );
		if ( ! is_array( $config ) || empty( $config['showCountryFlags'] ) || ! is_user_logged_in() || ! class_exists( 'WC_Customer' ) ) {
			return '';
		}

		$user_id  = get_current_user_id();
		$customer = new WC_Customer( $user_id );
		$country  = strtoupper( (string) $customer->get_billing_country() );
		if ( $this->is_valid_country_code( $country ) ) {
			return $country;
		}

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return '';
		}
		$orders = wc_get_orders(
			[
				'customer_id' => $user_id,
				'status'      => function_exists( 'wc_get_is_paid_statuses' ) ? wc_get_is_paid_statuses() : [ 'processing', 'completed' ],
				'limit'         => 1,
				'orderby'       => 'date',
				'order'         => 'DESC',
				'return'        => 'objects',
			]
		);
		$order = is_array( $orders ) && isset( $orders[0] ) && $orders[0] instanceof WC_Order ? $orders[0] : null;
		$country = $order ? strtoupper( (string) $order->get_billing_country() ) : '';

		return $this->is_valid_country_code( $country ) ? $country : '';
	}

	/**
	 * Validate an ISO country against WooCommerce's country list.
	 *
	 * @param string $country Country code.
	 * @return bool
	 */
	private function is_valid_country_code( string $country ): bool {
		if ( ! preg_match( '/^[A-Z]{2}$/', $country ) ) {
			return false;
		}

		$countries = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_countries() : [];
		return empty( $countries ) || array_key_exists( $country, $countries );
	}

	/**
	 * Store uploaded review media as WordPress attachments.
	 *
	 * @param int $product_id Product ID.
	 * @return array<int, int>
	 */
	private function handle_media_uploads( int $product_id ): array {
		if ( ! $this->has_uploaded_media() ) {
			return [];
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$files = $_FILES['os_review_media'];
		$ids   = [];
		$count = min( self::MAX_FILES, count( $files['name'] ) );

		for ( $index = 0; $index < $count; $index++ ) {
			if ( empty( $files['name'][ $index ] ) || ! empty( $files['error'][ $index ] ) || (int) $files['size'][ $index ] > $this->max_upload_bytes() ) {
				continue;
			}

			$file = [
				'name'     => sanitize_file_name( (string) $files['name'][ $index ] ),
				'type'     => (string) $files['type'][ $index ],
				'tmp_name' => (string) $files['tmp_name'][ $index ],
				'error'    => (int) $files['error'][ $index ],
				'size'     => (int) $files['size'][ $index ],
			];

			$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $this->allowed_mimes() );
			if ( empty( $check['type'] ) ) {
				continue;
			}

			$upload = wp_handle_upload( $file, [ 'test_form' => false, 'mimes' => $this->allowed_mimes() ] );
			if ( isset( $upload['error'] ) || empty( $upload['file'] ) ) {
				continue;
			}

			$attachment_id = wp_insert_attachment(
				[
					'post_mime_type' => (string) $upload['type'],
					'post_title'     => sanitize_file_name( pathinfo( (string) $upload['file'], PATHINFO_FILENAME ) ),
					'post_content'   => '',
					'post_status'    => 'inherit',
				],
				(string) $upload['file'],
				$product_id
			);

			if ( ! $attachment_id || is_wp_error( $attachment_id ) ) {
				continue;
			}

			$metadata = wp_generate_attachment_metadata( (int) $attachment_id, (string) $upload['file'] );
			if ( ! empty( $metadata ) ) {
				wp_update_attachment_metadata( (int) $attachment_id, $metadata );
			}

			$ids[] = (int) $attachment_id;
		}

		return $ids;
	}

	/**
	 * Allowed media MIME types.
	 *
	 * @return array<string, string>
	 */
	private function allowed_mimes(): array {
		return [
			'jpg|jpeg' => 'image/jpeg',
			'png'      => 'image/png',
			'webp'     => 'image/webp',
			'gif'      => 'image/gif',
			'mp4'      => 'video/mp4',
			'mov'      => 'video/quicktime',
			'webm'     => 'video/webm',
		];
	}

	/**
	 * Redirect back to product with a status flag.
	 *
	 * @param mixed  $url    Redirect URL.
	 * @param string $status Status slug.
	 * @return void
	 */
	private function redirect_with_status( $url, string $status ): void {
		$url      = is_string( $url ) && '' !== $url ? $url : home_url( '/' );
		$redirect = add_query_arg( 'overseek_review_status', rawurlencode( $status ), $url );
		wp_safe_redirect( esc_url_raw( $redirect . '#review_form' ) );
		exit;
	}

	/**
	 * Resolve the product from the submitted ID or originating product URL.
	 *
	 * @param int    $product_id Submitted product ID.
	 * @param string $redirect   Same-page redirect URL.
	 * @return int
	 */
	private function resolve_product_id( int $product_id, string $redirect ): int {
		if ( $product_id && wc_get_product( $product_id ) && in_array( get_post_type( $product_id ), [ 'product', 'product_variation' ], true ) ) {
			return $this->normalize_product_review_id( $product_id );
		}

		$path = wp_parse_url( $redirect, PHP_URL_PATH );
		if ( ! is_string( $path ) || '' === $path ) {
			return $product_id;
		}

		$scheme = wp_parse_url( home_url(), PHP_URL_SCHEME );
		$host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$url    = ( is_string( $scheme ) ? $scheme : 'https' ) . '://' . ( is_string( $host ) ? $host : '' ) . $path;
		$post_id = url_to_postid( $url );

		if ( $post_id && wc_get_product( $post_id ) && in_array( get_post_type( $post_id ), [ 'product', 'product_variation' ], true ) ) {
			return $this->normalize_product_review_id( (int) $post_id );
		}

		return $product_id;
	}

	private function normalize_product_review_id( int $product_id ): int {
		$product = $product_id > 0 ? wc_get_product( $product_id ) : null;
		if ( ! $product ) {
			return 0;
		}

		if ( 'product_variation' === get_post_type( $product_id ) && method_exists( $product, 'get_parent_id' ) ) {
			$parent_id = (int) $product->get_parent_id();
			return $parent_id > 0 ? $parent_id : 0;
		}

		return 'product' === get_post_type( $product_id ) ? $product_id : 0;
	}

	/**
	 * Get the submitted same-page redirect URL, falling back to a product URL.
	 *
	 * @param string $fallback Fallback redirect URL.
	 * @return string
	 */
	private function get_submitted_redirect_url( string $fallback ): string {
		$url = '';
		if ( ! empty( $_POST['redirect_to'] ) ) {
			$url = esc_url_raw( wp_unslash( $_POST['redirect_to'] ) );
		}

		if ( '' === $url ) {
			$referer = wp_get_referer();
			$url     = is_string( $referer ) ? $referer : '';
		}

		$url = wp_validate_redirect( $url, $fallback );

		return remove_query_arg( 'overseek_review_status', $url );
	}

	/**
	 * Get the current request URL for post-submit redirects.
	 *
	 * @return string
	 */
	private function get_current_request_url(): string {
		$scheme      = is_ssl() ? 'https' : 'http';
		$home_host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$host        = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : ( is_string( $home_host ) ? $home_host : '' );
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		$url         = wp_validate_redirect( esc_url_raw( $scheme . '://' . $host . $request_uri ), home_url( '/' ) );

		return remove_query_arg( 'overseek_review_status', $url );
	}

	/**
	 * Get a safe redirect URL for review submissions.
	 *
	 * @param int $product_id Product ID.
	 * @return string
	 */
	private function get_review_redirect_url( int $product_id ): string {
		if ( $product_id ) {
			$permalink = get_permalink( $product_id );
			if ( is_string( $permalink ) && '' !== $permalink ) {
				return $permalink;
			}
		}

		return home_url( '/' );
	}

	/**
	 * Maximum accepted upload size, capped by PHP/WordPress upload settings.
	 *
	 * @return int
	 */
	private function max_upload_bytes(): int {
		$per_file_limit = min( self::MAX_BYTES, (int) wp_max_upload_size() );
		$post_max       = function_exists( 'wp_convert_hr_to_bytes' ) ? (int) wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) ) : 0;
		if ( $post_max > MB_IN_BYTES ) {
			$aggregate_safe_limit = (int) floor( ( $post_max - MB_IN_BYTES ) / self::MAX_FILES );
			$per_file_limit       = min( $per_file_limit, $aggregate_safe_limit );
		}

		return max( 1, $per_file_limit );
	}

	/**
	 * Get current product ID.
	 *
	 * @return int
	 */
	private function get_current_product_id(): int {
		global $product;

		if ( $product instanceof WC_Product ) {
			return (int) $product->get_id();
		}

		$post_id = get_the_ID();
		return $post_id ? (int) $post_id : 0;
	}

	/**
	 * Normalize boolean-like shortcode values.
	 *
	 * @param mixed $value Value.
	 * @return bool
	 */
	private function truthy( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}

		return ! in_array( strtolower( (string) $value ), [ '0', 'false', 'no', 'off', '' ], true );
	}

	/**
	 * Get the post used as the native comment bucket for shop reviews.
	 *
	 * @return int
	 */
	private function get_shop_review_post_id(): int {
		if ( function_exists( 'wc_get_page_id' ) ) {
			$shop_id = (int) wc_get_page_id( 'shop' );
			if ( $shop_id > 0 ) {
				return $shop_id;
			}
		}

		$front_id = (int) get_option( 'page_on_front' );
		return $front_id > 0 ? $front_id : 1;
	}
}
