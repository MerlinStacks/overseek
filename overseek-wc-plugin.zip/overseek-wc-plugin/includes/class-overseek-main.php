<?php
/**
 * Main Plugin Class
 *
 * @package OverSeek
 * @since   1.0.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class OverSeek_Main
 *
 * The core plugin class responsible for loading dependencies and defining hooks.
 *
 * @since 1.0.0
 */
class OverSeek_Main
{
	/**
	 * Admin handler instance.
	 *
	 * @var OverSeek_Admin
	 */
	protected OverSeek_Admin $admin;

	/**
	 * Frontend handler instance.
	 *
	 * @var OverSeek_Frontend
	 */
	protected OverSeek_Frontend $frontend;

	/**
	 * Initialize the plugin classes.
	 */
	public function __construct()
	{
		$this->load_dependencies();
		$this->init_hooks();
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * @return void
	 */
	private function load_dependencies(): void
	{
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-admin.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-frontend.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-api.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-server-tracking.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-pixels.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-crawler-guard.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-fingerprint.php';
		require_once OVERSEEK_WC_PLUGIN_DIR . 'includes/class-overseek-web-vitals.php';
	}

	/**
	 * Initialize hooks for Admin and Frontend.
	 *
	 * @return void
	 */
	private function init_hooks(): void
	{
		// Initialize Admin.
		$this->admin = new OverSeek_Admin();
		add_action('admin_menu', [$this->admin, 'add_menu_page']);
		add_action('admin_init', [$this->admin, 'register_settings']);

		// Initialize Frontend.
		$this->frontend = new OverSeek_Frontend();
		add_action('wp_head', [$this->frontend, 'print_scripts']);

		// Initialize API.
		$api = new OverSeek_API();
		add_action('rest_api_init', [$api, 'register_routes']);

		// Initialize Server-Side Tracking (runs on WooCommerce hooks).
		if (get_option('overseek_enable_tracking')) {
			new OverSeek_Server_Tracking();
		}

		// Initialize Client-Side Pixel Tracking (fetches config from API).
		new OverSeek_Pixels();

		// Initialize Crawler Guard (blocks blacklisted bots at application level).
		// Not gated by tracking toggle — admins may want bot blocking without analytics.
		new OverSeek_Crawler_Guard();

		// Initialize Fingerprint Bot Detection (checkout-only, behavioral scoring).
		// Not gated by tracking toggle — bot protection is independent of analytics.
		new OverSeek_Fingerprint();

		// Initialize Web Vitals Collector.
		// Not gated by tracking toggle — performance data is independent of behavioural analytics.
		new OverSeek_Web_Vitals();
	}

	/**
	 * Run the plugin.
	 *
	 * @return void
	 */
	public function run(): void
	{
		// Post-initialization logic can go here.
	}
}

